import {useState, useEffect} from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import TopBar from '../components/TopBar';
import { useParams, useNavigate } from 'react-router-dom';



const Home = (props) => {

    const navigate = useNavigate();

    const [books, setBooks] = useState([]);
    useEffect(() =>{
        axios.get("http://localhost:8000/api/books")
        .then((res)=>{
            console.log(res.data);
            setBooks(res.data);
        })

        .catch((err)=>{
            console.log(err);
            
        })

    },[]);

    const goToEdit = () => {
        console.log("edit");
        navigate(`/books/${id}/edit`);
    }



    return (
    <>
        <TopBar title="Book Catalog"></TopBar>
        {/* <div>{JSON.stringify(books)}</div> */}
        <table class="table table-striped-columns" >
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Page count</th>
                    <th>Available</th>
                    <th>Book Page</th>
                </tr>
            </thead>
        <tbody>
            {
                books.map((book) =>{
                return <tr key={book._id}>
                <td><Link to={"/books/" + book._id}>{book.title}</Link></td>
                <td>{book.author}</td>
                <td>{book.pages}</td>
                <td>{book.isAvailable ? "Yes" : "No"} | <a href="" onClick={() => navigate(`/books/${book._id}/edit`)}>Edit</a></td>
                <td><button><Link to={"/books/" + book._id}>Book Details</Link></button></td>
            </tr>;
            })

            }
                
        </tbody>
        
        
        </table>
        <div>Home</div>
    </>
    );
    
    
    

};

export default Home




