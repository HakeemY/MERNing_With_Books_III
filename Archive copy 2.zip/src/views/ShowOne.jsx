import { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams, Link, useNavigate } from 'react-router-dom';
import TopBar from '../components/TopBar';

function ShowOne(props) {
    const navigate = useNavigate();
    const { id } = useParams();
    console.log(id);
    const [oneBook, setOneBook] = useState(null);

    useEffect(() => {
        axios.get("http://localhost:8000/api/books/" + id)
            .then((res) => {
                console.log(res.data);
                setOneBook(res.data);
            })

            .catch((err) => {
                console.log(err);

            })
    }, [id]);


    const deleteMe = () => {
        axios.delete(`http://localhost:8000/api/books/${id}`)
        .then((res) => {
            console.log(res.data);
            navigate("/");
        })
    }


    const goToEdit = () => {
        console.log("edit");
        navigate(`/books/${id}/edit`);
    }



    return (
        <div>
            {/* {JSON.stringify(oneBook)} */}
            {
                oneBook !== null ? (

                    <div>
                        <TopBar title={oneBook.title}></TopBar>
                        <br /><br />
                        <p>{oneBook.title}</p>
                        <br /><br />
                        <p>By {oneBook.author}</p>
                        <br /><br />
                        <h3>Page count: {oneBook.pages}</h3>
                        <br /><br />
                        {
                            oneBook.isAvailable ? <p style={{ color: "green" }}>Available for borrowing</p> : <p style={{ color: "red" }}>Not Available</p>
                        }
                        <br /><br />
                        <button onClick={() => deleteMe(id)} style={{ backgroundColor: "pink" }}>Borrow</button>
                        <br />
                        <button onClick={() => navigate(`/books/${id}/edit`)} style={{ backgroundColor: "pink" }}>Edit</button>


                    </div>
                ) : <div>loading.....</div>
            }

        </div>
    );
};

export default ShowOne;