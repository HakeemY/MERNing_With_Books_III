import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate, useParams } from 'react-router-dom'
import TopBar from '../components/TopBar';

function Create(props) {
    
    const navigate = useNavigate();

    const [title, setTitle] = useState("")
    const [author, setAuthor] = useState("")
    const [pages, setPages] = useState(0)
    const [isAvailable, setIsAvailable] = useState(true)
    const [errors, setErrors] = useState({})
    
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log({ title, author, isAvailable });
        axios.post("http://localhost:8000/api/books", {
            title,
            author,
            pages,
            isAvailable
        })
            .then((res) => {
                console.log(res.data);
                navigate("/books");
                
            })
            .catch((err) => {
                console.log(err.response.data.errors);
                setErrors(err.response.data.errors);
            });
    

};






return (
    <div>
        <TopBar title="Add Book"></TopBar>
        <form onSubmit={handleSubmit} action="/action_page.php" >
            <div>
                Title:
                <input value={title} onChange={(e) => setTitle(e.target.value)} />
                {errors.title && <p style={{color: "red"}}>{errors.title.message}</p>}

            </div>
            <br /><br />
            <div>
                Author Name:
                <input value={author} onChange={(e) => setAuthor(e.target.value)} />
                {errors.author && <p style={{color: "red"}}>{errors.author.message}</p>}
            </div>
            <br /><br />

            <div>
            <label for="quantity">Page Count:</label>
            <input type="number" id="quantity" name="quantity" min="0" value={pages} onChange={(e) => setPages(e.target.value)}/>
            {errors.pages && <p style={{color: "red"}}>{errors.pages.message}</p>}
            </div>
            <br /><br />
            <div>
                is it Available?
                <input type="checkbox" checked={isAvailable} onChange={(e) => setIsAvailable(e.target.checked)} />
                
            </div>

            <br /><br />
            <button>Add Book!</button>


        </form>
    </div>
)
}

export default Create