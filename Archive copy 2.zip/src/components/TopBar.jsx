import React from 'react'
import {Route, Routes, Link, Navigate} from "react-router-dom";

export default function TopBar(props) {
    const title = props.title

  return (
    <div style={{
        display:"flex",
    }}>
        <div>
            <button><Link to = "/books/create">ADD Book</Link></button>
            <button><Link to = "/books">Catalog</Link></button>
        </div>
        <div>
            <h1>{title}</h1>
        </div>
 
      </div>   
  )
}
