import './App.css'
import {Route, Routes, Link, Navigate} from "react-router-dom";
import Home from './views/Home';
import ShowOne from './views/ShowOne';
import Create from './views/Create';
import Edit from './views/Edit';


function App() {
  return (
    <>   
    {/* set up routes*/}
    <Routes>
    <Route path="/" element= {<Navigate to="/books"/>} />
    
      {/* Home Page*/}
    <Route path="/books" element={<Home/>} />

    {/* Create Page*/}
    
    <Route path="/books/create" element={<Create/>} />
    
    {/* Show one Book Page */}
    
    <Route path="/books/:id" element={<ShowOne/>} />
    
     {/* Edit Book Page */}
    
    <Route path="/books/:id/edit" element={<Edit/>} />
    
    </Routes>
    
    
    
    
    
    
    </>
  );

  }
export default App
